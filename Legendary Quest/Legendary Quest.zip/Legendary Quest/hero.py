import msvcrt
def create_hero():
    print("Create hero")
    print("1. Human(hp: 100, damage: 20)")
    print("2. Goblin(hp:80, damage: 10)")
    print("3. Orc(hp:120, damahe: 30)")
    var = msvcrt.getch()
    if ord(var)==ord("1"):
        hp=100
        damage=20
    if ord(var)==ord("2"):
        hp=80
        damage=10
    if ord(var)==ord("3"):
        hp=120
        damage=50
    return hp, damage

class hero():
    def __init__(self, hp, damage, x, y):
        self.hp = hp
        self.damage = damage
        self.x = x
        self.y = y