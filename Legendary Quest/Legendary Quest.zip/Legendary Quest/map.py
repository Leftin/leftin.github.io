class cell():
    pass
    def __init__(self, id, x, y, texture):
        self.id = id
        self.x = x
        self.y = y
        self.texture = texture

    def update_cell(self):
        if self.id==0:
            self.texture=" "
            self.hitbox=False
        if self.id==1:
            self.texture="#"
            self.hitbox=True
        if self.id==3:
            self.texture="M"
            self.hitbox=True
            
class map():
    def __init__(self, mapY, mapX):
        self.board=[]
        for i in range(mapY):
            self.board.append([])
            for j in range(mapX):
                self.board[i].append(cell(0, j, i, " "))

    def update_map(self, hero, monster):
        for j in range(len(self.board[1])):
            self.board[0][j].id=1
            self.board[len(self.board)-1][j].id = 1
        for i in range(len(self.board)):
            self.board[i][0].id=1
            self.board[i][len(self.board[1])-1].id=1
    
        for i in range(len(self.board)):
            for j in range(len(self.board[1])):
                self.board[i][j].update_cell()
                if i==hero.y and j==hero.x:
                    self.board[i][j].texture="@"
                if i==monster.y and j==monster.x:
                    self.board[i][j].texture="M"

    def write(self):
        for i in range(len(self.board)):
            for j in range(len(self.board[1])):
                print(self.board[i][j].texture, end="")
            print()
                