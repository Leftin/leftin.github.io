import msvcrt

def step(m, object, monster):
    var = msvcrt.getch()
    xb = object.x
    yb = object.y

    if ord(var)==ord("8"):
        object.y -= 1
    if ord(var)==ord("2"):
        object.y += 1
    if ord(var)==ord("6"):
        object.x += 1
    if ord(var)==ord("4"):
        object.x -= 1
    
    yc = object.y
    xc = object.x

    if m.board[yc][xc].hitbox==True:
        object.y = yb
        object.x = xb
    if yc==monster.y and xc==monster.x:
        object.y = yb
        object.x = xb
        monster.hp -= object.damage