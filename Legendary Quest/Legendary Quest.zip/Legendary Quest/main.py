# **Legendaru Quest**
#   Prod by Left

import os
import random
import msvcrt
import map
import control
import hero
import logic
import animate

mapX = 6
mapY = 6
run=True

rooms = 0
MAP=map.map(mapY, mapX)
hp, damage = hero.create_hero()
hero = hero.hero(hp, damage, 2, 4)
monster = logic.dunger(random.randint(80, 130), random.randint(5, 20), 2, 1)

while run:
    os.system("cls")
    MAP.update_map(hero, monster)    
    monster.logic(hero, MAP)    
    MAP.write()
    print(f"\nYour hp: {hero.hp}\nYour damage: {hero.damage}\n\nMonsters hp: {monster.hp}\nMonster damage: {monster.damage}\n\nRooms: {rooms}")
    if hero.hp <= 0:
        os.system("cls")
        print("You lose:P")
        print(f"You passed {rooms} rooms")
        msvcrt.getch()
        exit()


    control.step(MAP, hero, monster)
    
    if monster.hp <= 0:
        rooms +=1
        monster = logic.dunger(random.randint(80, 130), random.randint(10, 30), 2, 1)
        hero.x = 2
        hero.y = 4
        animate.load()