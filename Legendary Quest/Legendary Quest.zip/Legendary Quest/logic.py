class dunger():
    def __init__(self, hp, damage, x, y):
        self.hp = hp
        self.damage = damage
        self.x = x
        self.y = y

    def logic(self, hero, map):
        xb = self.x
        yb = self.y
        if self.hp <=20:
            if hero.x < self.x:
                self.x += 1
            if hero.x > self.x:
                self.x -= 1
            if hero.y < self.x:
                self.y += 1
            if hero.y > self.x:
                self.y -= 1
        if self.hp > 20:
            if hero.x < self.x:
                self.x -= 1
            if hero.x > self.x:
                self.x += 1
            if hero.y < self.x:
                self.y -= 1
            if hero.y > self.x:
                self.y += 1
        if self.x==hero.x and self.y==hero.y:
            self.x = xb
            self.y = yb
            hero.hp -= self.damage
        if map.board[self.y][self.x].hitbox==True:
            self.x = xb
            self.y = yb